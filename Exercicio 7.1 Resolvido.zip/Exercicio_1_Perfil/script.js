function atualizarPerfil() {
    // 1. Declarar as três variáveis
    const nome = "Beatriz Feitosa";
    const idade = 25;
    const bio = "Estudante de Análise e Desenvolvimento de Sistemas, interessada em tecnologia, programação e desenvolvimento web.";

    // 2. Atualizar os elementos HTML utilizando o DOM
    document.getElementById("nome").textContent = nome;
    document.getElementById("idade").textContent = "Idade: " + idade;
    document.getElementById("biografia").textContent = bio;
}
