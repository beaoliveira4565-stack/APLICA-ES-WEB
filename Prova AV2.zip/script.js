// Guarda o card que foi clicado no momento
var cardAtualSelecionado = null;

// Missão 3: idade total da criança em meses (null = ainda não informada)
var idadeTotalMeses = null;

// --- PARTE 1: CÁLCULO AUTOMÁTICO DE IDADE (ANOS E MESES) ---
var campoNascimento = document.getElementById('dataNascimento');
var campoIdadeAnos = document.getElementById('idadeAnos');
var campoIdadeMeses = document.getElementById('idadeMeses');

campoNascimento.addEventListener('change', function() {
  var valorData = campoNascimento.value;

  if (valorData === '') {
    campoIdadeAnos.value = '';
    campoIdadeMeses.value = '';
    idadeTotalMeses = null;
    atualizarAtrasos();
    return;
  }

  var partes = valorData.split('-');
  var anoNasc = parseInt(partes[0], 10);
  var mesNasc = parseInt(partes[1], 10);
  var diaNasc = parseInt(partes[2], 10);

  var hoje = new Date();
  var anoHoje = hoje.getFullYear();
  var mesHoje = hoje.getMonth() + 1;
  var diaHoje = hoje.getDate();

  var anos = anoHoje - anoNasc;
  var meses = mesHoje - mesNasc;

  if (diaHoje < diaNasc) {
    meses = meses - 1;
  }

  if (meses < 0) {
    anos = anos - 1;
    meses = meses + 12;
  }

  if (anos < 0) {
    alert('De geboortedatum mag niet na de datum van vandaag liggen!');
    campoNascimento.value = '';
    campoIdadeAnos.value = '';
    campoIdadeMeses.value = '';
    idadeTotalMeses = null;
    atualizarAtrasos();
    return;
  }

  campoIdadeAnos.value = anos + ' jaar';
  campoIdadeMeses.value = meses + (meses === 1 ? ' maand' : ' maanden');

  // Missão 3: guarda a idade total em meses e marca as vacinas atrasadas
  idadeTotalMeses = anos * 12 + meses;
  atualizarAtrasos();
});


// --- PARTE 2: FUNÇÕES DE VALIDAÇÃO DE BSN E CARTÃO SUS ---
function limparNumeros(texto) {
  var resultado = '';
  for (var i = 0; i < texto.length; i++) {
    var caractere = texto[i];
    if (caractere >= '0' && caractere <= '9') {
      resultado = resultado + caractere;
    }
  }
  return resultado;
}

/*
  Missão 2 - Validação do BSN (Burgerservicenummer), o documento de identificação
  holandês (equivalente ao CPF). Regra chamada "elfproef" (prova dos 11):
   1) O BSN tem 9 dígitos (números antigos de 8 dígitos recebem um zero à esquerda).
   2) Multiplica-se cada dígito pelo seu peso: 9, 8, 7, 6, 5, 4, 3, 2 e -1
      (o peso do ÚLTIMO dígito é NEGATIVO).
   3) Soma-se tudo. O BSN é válido se a soma for diferente de 0 e divisível por 11.
  Exemplo válido: 111222333 -> 9+8+7+12+10+8+9+6-3 = 66 (66 / 11 = 6).
*/
function validarBSN(bsnTexto) {
  var bsn = limparNumeros(bsnTexto);

  if (bsn.length === 8) {
    bsn = '0' + bsn;
  }

  if (bsn.length !== 9) {
    return false;
  }

  var pesos = [9, 8, 7, 6, 5, 4, 3, 2, -1];
  var soma = 0;
  for (var i = 0; i < 9; i++) {
    soma = soma + parseInt(bsn[i], 10) * pesos[i];
  }

  return soma !== 0 && soma % 11 === 0;
}

function validarCartaoSUS(susTexto) {
  var cns = limparNumeros(susTexto);

  if (cns.length !== 15) {
    return false;
  }

  var primeiroDigito = cns[0];
  if (
    primeiroDigito !== '1' &&
    primeiroDigito !== '2' &&
    primeiroDigito !== '7' &&
    primeiroDigito !== '8' &&
    primeiroDigito !== '9'
  ) {
    return false;
  }

  var soma = 0;
  for (var i = 0; i < 15; i++) {
    soma = soma + parseInt(cns[i], 10) * (15 - i);
  }

  return soma % 11 === 0;
}


// --- PARTE 3: ENVIO E VALIDAÇÃO DO FORMULÁRIO DA CRIANÇA ---
var formulario = document.getElementById('form-crianca');

// Missão 2: mostra a mensagem de erro logo abaixo do campo (ao sair do campo e ao digitar)
function ligarValidacao(idCampo, funcaoValida, mensagem) {
  var campo = document.getElementById(idCampo);
  var erro = document.getElementById('erro-' + idCampo);

  function checar() {
    if (campo.value === '') {
      erro.textContent = '';
      campo.classList.remove('invalido');
      return true;
    }
    var ok = funcaoValida(campo.value);
    erro.textContent = ok ? '' : mensagem;
    if (ok) {
      campo.classList.remove('invalido');
    } else {
      campo.classList.add('invalido');
    }
    return ok;
  }

  campo.addEventListener('blur', checar);
  campo.addEventListener('input', function() {
    if (erro.textContent !== '') {
      checar();
    }
  });
  return checar;
}

var checarBSN = ligarValidacao('bsnCrianca', validarBSN, 'Ongeldig BSN. Controleer de cijfers en probeer het opnieuw.');
var checarSUS = ligarValidacao('numeroSus', validarCartaoSUS, 'Ongeldig SUS-kaartnummer. Het moet uit 15 geldige cijfers bestaan.');

formulario.addEventListener('submit', function(evento) {
  evento.preventDefault();

  var nome = document.getElementById('nomeCrianca').value;
  var nascimento = document.getElementById('dataNascimento').value;
  var bsn = document.getElementById('bsnCrianca').value;
  var sus = document.getElementById('numeroSus').value;
  var resp1 = document.getElementById('responsavel1').value;

  if (nome === '' || nascimento === '' || bsn === '' || sus === '' || resp1 === '') {
    alert('Vul alle verplichte velden in die met * zijn gemarkeerd!');
    return;
  }

  if (!checarBSN()) {
    alert('Het ingevulde BSN is ongeldig! Controleer de cijfers en probeer het opnieuw.');
    return;
  }

  if (!checarSUS()) {
    alert('Het nummer van de SUS-kaart (CNS) is ongeldig! Het moet 15 geldige cijfers bevatten.');
    return;
  }

  // Missão 4: dados válidos -> baixa o arquivo JSON local com a carteirinha
  var nomeArquivo = salvarCarteirinha();

  var mensagem = document.getElementById('mensagem-cadastro');
  mensagem.textContent = 'Gegevens van ' + nome + ' zijn gevalideerd en opgeslagen in het bestand ' + nomeArquivo + '!';
});

// --- Missão 4: SALVAR A CARTEIRINHA EM ARQUIVO JSON LOCAL ---
function salvarCarteirinha() {
  var cards = document.querySelectorAll('.card-vacina');
  var listaVacinas = [];

  for (var i = 0; i < cards.length; i++) {
    var c = cards[i];
    var status = 'openstaand';
    if (c.classList.contains('tomada')) {
      status = 'toegediend';
    } else if (c.classList.contains('atrasada')) {
      status = 'achterstallig';
    }

    listaVacinas.push({
      vaccin: c.dataset.vacina,
      dosis: c.dataset.dose,
      leeftijd: c.dataset.idade,
      status: status,
      datum_toediening: c.dataset.dataAplicacao || '',
      lotnummer: c.dataset.numeroLote || '',
      toedienende_instantie: c.dataset.unidadeAplicadora || '',
      verantwoordelijke: c.dataset.responsavelAplicacao || ''
    });
  }

  var dadosCarteira = {
    kind: {
      naam: document.getElementById('nomeCrianca').value,
      geboortedatum: document.getElementById('dataNascimento').value,
      leeftijd_jaren: document.getElementById('idadeAnos').value,
      leeftijd_maanden: document.getElementById('idadeMeses').value,
      bsn: limparNumeros(document.getElementById('bsnCrianca').value),
      sus_nummer: limparNumeros(document.getElementById('numeroSus').value),
      ouder_verzorger_1: document.getElementById('responsavel1').value,
      ouder_verzorger_2: document.getElementById('responsavel2').value
    },
    vaccinaties: listaVacinas
  };

  var texto = JSON.stringify(dadosCarteira, null, 2);
  var arquivo = new Blob([texto], { type: 'application/json' });
  var nomeLimpo = dadosCarteira.kind.naam.replace(/[^a-zA-Z0-9]+/g, '_');
  var nomeArquivo = 'vaccinatieboekje_' + nomeLimpo + '.json';

  var link = document.createElement('a');
  link.href = URL.createObjectURL(arquivo);
  link.download = nomeArquivo;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(link.href);

  return nomeArquivo;
}


// --- PARTE 4: CARREGAR O ARQUIVO JSON E CRIAR OS CARDS ---
fetch('vacinasSUS.json')
  .then(function(resposta) {
    return resposta.json();
  })
  .then(function(dados) {
    var listaVacinas = dados.calendario_vacinacao_infantil_sus;
    var containerCards = document.getElementById('lista-vacinas');

    for (var i = 0; i < listaVacinas.length; i++) {
      var vacinaAtual = listaVacinas[i];
      var dosesSeparadas = separarDoses(vacinaAtual.idade);

      for (var j = 0; j < dosesSeparadas.length; j++) {
        criarCardNaTela(
          containerCards,
          vacinaAtual.vacina,
          dosesSeparadas[j],
          vacinaAtual.para_que_serve,
          j + 1
        );
      }
    }
  })
  .then(function() {
    // Missão 3: se a data de nascimento já foi informada, marca os atrasos
    atualizarAtrasos();
  })
  .catch(function(erro) {
    console.log('Erro ao carregar JSON:', erro);
    document.getElementById('lista-vacinas').innerHTML =
      '<p>Fout bij het laden van vacinasSUS.json. Open de pagina met Live Server.</p>';
  });

function separarDoses(texto) {
  if (texto.indexOf(';') !== -1) {
    return [texto];
  }
  var textoComVirgulas = texto.replace(' en ', ', ');
  return textoComVirgulas.split(', ');
}

// Missão 3: descobre até que idade (em meses) a dose deve ser tomada.
// Ex.: "2 maanden (1e dosis)" -> 2 | "4 jaar (booster)" -> 48 | "9 tot 14 jaar" -> 168 (fim da faixa)
// "Bij de geboorte" (sem número) -> 0
function calcularMesesLimite(textoIdade) {
  var m = textoIdade.match(/(\d+)(?:\s*tot\s*(\d+))?\s*(maand|jaar)/);
  if (m === null) {
    return 0;
  }
  var numero = parseInt(m[2] || m[1], 10);
  return m[3] === 'jaar' ? numero * 12 : numero;
}

// Missão 3: marca em vermelho (e com o texto "Achterstallig") as vacinas atrasadas
function atualizarAtrasos() {
  var cards = document.querySelectorAll('.card-vacina');
  var totalAtrasadas = 0;

  for (var i = 0; i < cards.length; i++) {
    var card = cards[i];
    var textoStatus = card.querySelector('.status-texto');

    if (card.classList.contains('tomada')) {
      card.classList.remove('atrasada');
    } else if (idadeTotalMeses !== null && idadeTotalMeses > parseInt(card.dataset.mesesLimite, 10)) {
      card.classList.add('atrasada');
      textoStatus.textContent = 'Status: Achterstallig ⚠';
      totalAtrasadas++;
    } else {
      card.classList.remove('atrasada');
      textoStatus.textContent = 'Status: Openstaand';
    }
  }

  var resumo = document.getElementById('resumo-atrasos');
  if (totalAtrasadas > 0) {
    resumo.textContent = '⚠ ' + totalAtrasadas + (totalAtrasadas === 1 ? ' achterstallig vaccin' : ' achterstallige vaccins') + ' - neem contact op met uw huisarts of consultatiebureau.';
  } else {
    resumo.textContent = '';
  }
}

function criarCardNaTela(container, nomeVacina, idadeDose, descricao, numeroDose) {
  var card = document.createElement('div');
  card.className = 'card-vacina';

  // Guarda dados no card (usados nas missões 3 e 4)
  card.dataset.vacina = nomeVacina;
  card.dataset.dose = 'Dosis ' + numeroDose;
  card.dataset.idade = idadeDose;
  card.dataset.mesesLimite = calcularMesesLimite(idadeDose);

  card.innerHTML =
    '<span class="etiqueta-dose">Dosis ' + numeroDose + '</span>' +
    '<h3>' + nomeVacina + '</h3>' +
    '<p><strong>Leeftijd:</strong> ' + idadeDose + '</p>' +
    '<p class="status-texto">Status: Openstaand</p>' +
    '<div class="detalhes-aplicacao-card escondido"></div>';

  card.addEventListener('click', function() {
    abrirJanela(card, nomeVacina, numeroDose, idadeDose, descricao);
  });

  container.appendChild(card);
}


// --- PARTE 5: CONTROLE DA JANELA (MODAL) E DADOS DA APLICAÇÃO ---
var janela = document.getElementById('janela-detalhes');
var checkTomada = document.getElementById('check-tomada');
var camposAplicacao = document.getElementById('campos-aplicacao');

var inputDataAplicacao = document.getElementById('dataAplicacao');
var inputNumeroLote = document.getElementById('numeroLote');
var inputUnidadeAplicadora = document.getElementById('unidadeAplicadora');
var inputResponsavelAplicacao = document.getElementById('responsavelAplicacao');

var btnConfirmar = document.getElementById('btn-confirmar');
var btnFechar = document.getElementById('btn-fechar');

// Mostra ou esconde os 4 campos extras quando o checkbox muda
checkTomada.addEventListener('change', function() {
  if (checkTomada.checked === true) {
    camposAplicacao.classList.remove('escondido');
  } else {
    camposAplicacao.classList.add('escondido');
  }
});

// Função simples para converter YYYY-MM-DD em DD-MM-YYYY (formato holandês)
function formatarDataBrasil(dataISO) {
  if (dataISO === '') return '';
  var partes = dataISO.split('-');
  return partes[2] + '-' + partes[1] + '-' + partes[0];
}

function abrirJanela(cardClicado, nome, numDose, idade, descricao) {
  cardAtualSelecionado = cardClicado;

  document.getElementById('janela-titulo').textContent = nome;
  document.getElementById('janela-dose').textContent = 'Dosis ' + numDose;
  document.getElementById('janela-idade').textContent = idade;
  document.getElementById('janela-descricao').textContent = descricao;

  // Verifica se o card já estava marcado como tomado
  if (cardClicado.classList.contains('tomada')) {
    checkTomada.checked = true;
    camposAplicacao.classList.remove('escondido');

    // Recupera os valores salvos anteriormente no próprio card
    inputDataAplicacao.value = cardClicado.dataset.dataAplicacao || '';
    inputNumeroLote.value = cardClicado.dataset.numeroLote || '';
    inputUnidadeAplicadora.value = cardClicado.dataset.unidadeAplicadora || '';
    inputResponsavelAplicacao.value = cardClicado.dataset.responsavelAplicacao || '';
  } else {
    checkTomada.checked = false;
    camposAplicacao.classList.add('escondido');

    // Limpa os campos para um novo preenchimento
    inputDataAplicacao.value = '';
    inputNumeroLote.value = '';
    inputUnidadeAplicadora.value = '';
    inputResponsavelAplicacao.value = '';
  }

  janela.classList.remove('escondido');
}

btnConfirmar.addEventListener('click', function() {
  if (cardAtualSelecionado !== null) {
    var textoStatus = cardAtualSelecionado.querySelector('.status-texto');
    var caixaDetalhesCard = cardAtualSelecionado.querySelector('.detalhes-aplicacao-card');

    if (checkTomada.checked === true) {
      var dataApl = inputDataAplicacao.value;
      var lote = inputNumeroLote.value;
      var unidade = inputUnidadeAplicadora.value;
      var responsavel = inputResponsavelAplicacao.value;

      // Valida se os campos da aplicação foram preenchidos (lote sem verificação de formato)
      if (dataApl === '' || lote === '' || unidade === '' || responsavel === '') {
        alert('Vul de datum van toediening, het lotnummer, de toedienende instantie en de verantwoordelijke in!');
        return;
      }

      // Salva os dados no próprio elemento HTML do card usando dataset
      cardAtualSelecionado.dataset.dataAplicacao = dataApl;
      cardAtualSelecionado.dataset.numeroLote = lote;
      cardAtualSelecionado.dataset.unidadeAplicadora = unidade;
      cardAtualSelecionado.dataset.responsavelAplicacao = responsavel;

      cardAtualSelecionado.classList.add('tomada');
      textoStatus.textContent = 'Status: Toegediend ✓';

      // Mostra o resumo da aplicação dentro do card
      caixaDetalhesCard.innerHTML =
        '<strong>Datum:</strong> ' + formatarDataBrasil(dataApl) + '<br>' +
        '<strong>Lotnummer:</strong> ' + lote + '<br>' +
        '<strong>Instantie:</strong> ' + unidade + '<br>' +
        '<strong>Verantwoordelijke:</strong> ' + responsavel;
      caixaDetalhesCard.classList.remove('escondido');

    } else {
      // Se desmarcou a opção, volta o card para Pendente e limpa os dados
      cardAtualSelecionado.classList.remove('tomada');
      textoStatus.textContent = 'Status: Openstaand';
      caixaDetalhesCard.innerHTML = '';
      caixaDetalhesCard.classList.add('escondido');

      delete cardAtualSelecionado.dataset.dataAplicacao;
      delete cardAtualSelecionado.dataset.numeroLote;
      delete cardAtualSelecionado.dataset.unidadeAplicadora;
      delete cardAtualSelecionado.dataset.responsavelAplicacao;
    }
  }

  // Missão 3: recalcula os atrasos depois de confirmar/desmarcar uma vacina
  atualizarAtrasos();

  janela.classList.add('escondido');
});

btnFechar.addEventListener('click', function() {
  janela.classList.add('escondido');
});